﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Management
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, n;
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            StudentDetails[] ob = new StudentDetails[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new StudentDetails();
                ob[i].getdata();
            }
            for (i = 0; i < n; i++)
            {
                ob[i].display();
            }
        }
    }
}
