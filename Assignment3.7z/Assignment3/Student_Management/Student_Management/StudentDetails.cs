﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Management
{
    class StudentDetails
    {
        public int age,rollNum;
        public string studentName,fName,mName,Address,classTeacher,gender,branch;
        public float attendance,marksPercentage;
        public double studentMobileNum;


        public void getdata()
        {
            Console.Write("Enter student name  =  ");
            studentName = Console.ReadLine();
            Console.Write("Enter roll number  =  ");
            rollNum = int.Parse(Console.ReadLine());
            Console.Write("Enter age  =  ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter branch name =  ");
            branch = Console.ReadLine();
            Console.Write("Enter student mobile Number =  ");
            studentMobileNum = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter student gender = ");
            gender = Console.ReadLine();
            Console.WriteLine("Enter student class teacher Name = ");
            classTeacher= Console.ReadLine();
            Console.WriteLine("Enter student father Name = ");
            fName = Console.ReadLine();
            Console.WriteLine("Enter student mother Name = ");
            mName = Console.ReadLine();
            Console.WriteLine("Enter student adress = ");
            Address = Console.ReadLine();
            Console.WriteLine("Enter student attendance per month = ");
            attendance = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter student marks percentage = ");
            marksPercentage= float.Parse(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("______________________________");

            Console.Write("NAME "+"\t"+"ROLL"+"\t"+ "Age"+"\t"+ "gender"+"\t"+ 
                          "branch"+"\t"+"mobileno"+"\t"+"Address"+"\t\t"+"Teacher"+"\t"+
                          "fname"+"\t"+ "mname"+"\t"+ "attendance"+"\t"+ "percentage");
            Console.WriteLine();
            Console.WriteLine(studentName+"\t"+ rollNum+"\t"+ age+"\t"+ gender+"\t"+
                              branch+"\t"+ studentMobileNum+"\t"+ Address+"\t\t"+ classTeacher+"\t"+
                              fName+"\t"+mName+"\t"+ attendance+"\t\t"+ marksPercentage);
     
           /* Console.Write("ROLL NUMBER " + rollNum + "\t");
            Console.Write("Age " + age + "\t");
            Console.Write("gender " + gender + "\t");
            Console.Write("CLASS " + classNum + "\t");
            Console.Write("mobileno " + studentMobileNum + "\t");
            Console.Write("Address " + Address + "\t");
            Console.Write("ClassTeacher " + classTeacher + "\t");
            Console.Write("fathername " + fName + "\t");
            Console.Write("mothername " + mName + "\t");
            Console.Write("attendance " + attendance + "\t");
            Console.Write("percentage " + marksPercentage + "\t");*/
        }
    }
}
